import SwiftUI

struct SplashScreenView: View {
    @State private var isAnimating = false
    @State private var showSplash = true
    @State private var scaleEffect: CGFloat = 0.5
    @State private var rotationAngle: Double = 0
    @State private var opacity: Double = 0
    
    var body: some View {
        ZStack {
            // Modern gradient background matching LoginView
            LinearGradient(
                colors: [
                    Color(red: 0.1, green: 0.1, blue: 0.2),
                    Color(red: 0.2, green: 0.2, blue: 0.3),
                    Color(red: 0.15, green: 0.15, blue: 0.25)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            // Animated growing crowns background
            SplashAnimatedCrownsView()
            
            if showSplash {
                VStack(spacing: 40) {
                    // Modern rabbit icon with enhanced animations
                    RabbitCrownIcon()
                        .frame(width: 140, height: 140)
                        .scaleEffect(scaleEffect)
                        .rotationEffect(.degrees(rotationAngle))
                        .opacity(opacity)
                        .shadow(color: .yellow.opacity(0.3), radius: 25, x: 0, y: 15)
                        .shadow(color: .black.opacity(0.2), radius: 15, x: 0, y: 8)
                    
                    // Modern app title section
                    VStack(spacing: 12) {
                        Text("King Company")
                            .font(.system(size: 48, weight: .bold, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.white, .white.opacity(0.8)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .opacity(opacity)
                        
                        Text("An experience like no other")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.white.opacity(0.7))
                            .opacity(opacity * 0.8)
                    }
                    .offset(y: isAnimating ? 0 : 30)
                    
                    // Modern loading indicator
                    VStack(spacing: 16) {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(1.5)
                            .opacity(opacity)
                        
                        Text("Loading your experience...")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.white.opacity(0.6))
                            .opacity(opacity * 0.7)
                    }
                }
                .onAppear {
                    startAnimations()
                }
            } else {
                // Transition to Login View after splash with animation
                NavigationView {
                    LoginView()
                }
                .transition(.opacity.combined(with: .scale))
            }
        }
        .animation(.easeInOut(duration: 0.8), value: showSplash)
    }
    
    private func startAnimations() {
        // Initial dramatic fade in and scale animation
        withAnimation(.easeOut(duration: 1.2)) {
            opacity = 1.0
            scaleEffect = 1.0
        }
        
        // Enhanced bounce effect
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.5)) {
                scaleEffect = 1.15
            }
            
            // Return to normal with overshoot
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                    scaleEffect = 1.0
                }
            }
        }
        
        // Enhanced rotation animation sequence
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            withAnimation(.easeInOut(duration: 0.6)) {
                rotationAngle = 8
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                withAnimation(.easeInOut(duration: 0.6)) {
                    rotationAngle = -8
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                    withAnimation(.easeInOut(duration: 0.8)) {
                        rotationAngle = 0
                    }
                }
            }
        }
        
        // Text slide in animation with delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            withAnimation(.easeOut(duration: 0.8)) {
                isAnimating = true
            }
        }
        
        // Extended display time for better user experience
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
            withAnimation(.easeInOut(duration: 0.8)) {
                showSplash = false
            }
        }
    }
}

// Enhanced rabbit crown icon with modern styling
struct RabbitCrownIcon: View {
    var body: some View {
        ZStack {
            // Enhanced rabbit body with gradient
            RabbitShape()
                .fill(
                    LinearGradient(
                        colors: [.white, .white.opacity(0.9)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .stroke(Color.black.opacity(0.8), lineWidth: 4)
            
            // Enhanced crown with glow effect
            Crown()
                .offset(x: 15, y: -25)
                .shadow(color: .yellow.opacity(0.6), radius: 10, x: 0, y: 0)
            
            // Enhanced rabbit features
            RabbitFeatures()
        }
    }
}

struct RabbitShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.width
        let height = rect.height
        
        // Main body (oval)
        let bodyRect = CGRect(x: width * 0.2, y: width * 0.4, width: width * 0.6, height: width * 0.5)
        path.addEllipse(in: bodyRect)
        
        // Head (circle)
        let headCenter = CGPoint(x: width * 0.6, y: height * 0.35)
        let headRadius = width * 0.25
        path.addEllipse(in: CGRect(x: headCenter.x - headRadius, y: headCenter.y - headRadius,
                                  width: headRadius * 2, height: headRadius * 2))
        
        // Left ear
        path.move(to: CGPoint(x: width * 0.45, y: height * 0.15))
        path.addQuadCurve(to: CGPoint(x: width * 0.35, y: height * 0.35),
                         control: CGPoint(x: width * 0.3, y: height * 0.2))
        path.addQuadCurve(to: CGPoint(x: width * 0.5, y: height * 0.25),
                         control: CGPoint(x: width * 0.4, y: height * 0.3))
        
        // Right ear (added for symmetry)
        path.move(to: CGPoint(x: width * 0.75, y: height * 0.15))
        path.addQuadCurve(to: CGPoint(x: width * 0.85, y: height * 0.35),
                         control: CGPoint(x: width * 0.9, y: height * 0.2))
        path.addQuadCurve(to: CGPoint(x: width * 0.7, y: height * 0.25),
                         control: CGPoint(x: width * 0.8, y: height * 0.3))
        
        // Tail
        let tailCenter = CGPoint(x: width * 0.15, y: height * 0.7)
        path.addEllipse(in: CGRect(x: tailCenter.x - 10, y: tailCenter.y - 10, width: 20, height: 20))
        
        return path
    }
}

struct Crown: View {
    var body: some View {
        ZStack {
            // Enhanced crown base with gradient
            RoundedRectangle(cornerRadius: 6)
                .fill(
                    LinearGradient(
                        colors: [Color.yellow, Color.orange.opacity(0.8)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .frame(width: 45, height: 14)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(Color.black.opacity(0.8), lineWidth: 2)
                )
            
            // Enhanced crown points with gradients
            HStack(spacing: 10) {
                ForEach(0..<3, id: \.self) { index in
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [Color.yellow, Color.orange.opacity(0.7)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: index == 1 ? 14 : 10, height: index == 1 ? 14 : 10)
                        .overlay(Circle().stroke(Color.black.opacity(0.8), lineWidth: 2))
                        .offset(y: index == 1 ? -10 : -6)
                        .shadow(color: .yellow.opacity(0.4), radius: 4, x: 0, y: 2)
                }
            }
            
            // Enhanced crown jewels with sparkle effect
            HStack(spacing: 14) {
                ForEach(0..<3, id: \.self) { index in
                    Circle()
                        .fill(Color.white.opacity(0.9))
                        .frame(width: 4, height: 4)
                        .offset(y: index == 1 ? -10 : -6)
                        .shadow(color: .white, radius: 2, x: 0, y: 0)
                }
            }
        }
    }
}

struct RabbitFeatures: View {
    var body: some View {
        VStack {
            HStack(spacing: 20) {
                // Enhanced eyes
                Circle()
                    .fill(Color.black)
                    .frame(width: 8, height: 8)
                    .overlay(
                        Circle()
                            .fill(Color.white)
                            .frame(width: 2, height: 2)
                            .offset(x: -1, y: -1)
                    )
                    .offset(x: 10, y: -8)
                
                Circle()
                    .fill(Color.black)
                    .frame(width: 8, height: 8)
                    .overlay(
                        Circle()
                            .fill(Color.white)
                            .frame(width: 2, height: 2)
                            .offset(x: -1, y: -1)
                    )
                    .offset(x: 20, y: -8)
            }
            
            // Enhanced nose
            Circle()
                .fill(Color.pink.opacity(0.8))
                .frame(width: 5, height: 5)
                .overlay(Circle().stroke(Color.black.opacity(0.6), lineWidth: 1))
                .offset(x: 15, y: 2)
        }
    }
}

// MARK: - Splash-specific Animated Growing Crowns
struct SplashAnimatedCrownsView: View {
    @State private var splashCrowns: [SplashCrown] = []
    
    var body: some View {
        ZStack {
            ForEach(splashCrowns, id: \.id) { crown in
                Image(systemName: "crown.fill")
                    .font(.system(size: crown.size))
                    .foregroundColor(.yellow.opacity(crown.opacity))
                    .position(x: crown.x, y: crown.y)
                    .rotationEffect(.degrees(crown.rotation))
                    .scaleEffect(crown.scale)
                    .shadow(color: .yellow.opacity(0.4), radius: crown.glowRadius, x: 0, y: 0)
            }
        }
        .onAppear {
            createSplashCrowns()
            startCrownAnimations()
        }
    }
    
    private func createSplashCrowns() {
        for _ in 0..<12 {
            let crown = SplashCrown(
                id: UUID(),
                x: CGFloat.random(in: 30...UIScreen.main.bounds.width - 30),
                y: CGFloat.random(in: 80...UIScreen.main.bounds.height - 80),
                size: CGFloat.random(in: 20...40),
                opacity: Double.random(in: 0.1...0.3),
                rotation: Double.random(in: 0...360),
                scale: 0.1,
                glowRadius: CGFloat.random(in: 5...15)
            )
            splashCrowns.append(crown)
        }
    }
    
    private func startCrownAnimations() {
        for i in 0..<splashCrowns.count {
            let delay = Double.random(in: 0...3.0)
            let growDuration = Double.random(in: 2.0...4.0)
            let floatDuration = Double.random(in: 4.0...8.0)
            
            // Random growing animation
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                withAnimation(.easeOut(duration: growDuration)) {
                    splashCrowns[i].scale = CGFloat.random(in: 0.8...1.5)
                    splashCrowns[i].opacity = Double.random(in: 0.2...0.5)
                }
                
                // Continuous floating and rotation
                DispatchQueue.main.asyncAfter(deadline: .now() + growDuration) {
                    animateCrownFloating(at: i, duration: floatDuration)
                }
            }
        }
    }
    
    private func animateCrownFloating(at index: Int, duration: Double) {
        withAnimation(.easeInOut(duration: duration).repeatForever(autoreverses: true)) {
            splashCrowns[index].y += CGFloat.random(in: -60...60)
            splashCrowns[index].x += CGFloat.random(in: -40...40)
            splashCrowns[index].rotation += Double.random(in: -30...30)
            splashCrowns[index].scale *= CGFloat.random(in: 0.8...1.2)
        }
        
        // Opacity pulsing
        withAnimation(.easeInOut(duration: duration * 0.6).repeatForever(autoreverses: true)) {
            splashCrowns[index].opacity *= Double.random(in: 0.5...1.5)
        }
    }
}

struct SplashCrown {
    let id: UUID
    var x: CGFloat
    var y: CGFloat
    let size: CGFloat
    var opacity: Double
    var rotation: Double
    var scale: CGFloat
    let glowRadius: CGFloat
}

// Preview
struct SplashScreenView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView()
    }
}
