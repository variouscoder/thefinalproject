//
//  forgot password.swift
//  Userauth
//
//  Created by Tarik Eddins on 7/30/25.
//

import SwiftUI

struct forgot_password: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    forgot_password()
}
