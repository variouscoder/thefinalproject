import SwiftUI

// Add this at the top level for dark mode management
class AppSettings: ObservableObject {
    @Published var isDarkMode = false
}

struct Navbar: View {
    @StateObject private var appSettings = AppSettings()
    
    var body: some View {
        NavigationView {
            MenuView()
                .navigationBarHidden(true)
        }
        .environmentObject(appSettings)
        .preferredColorScheme(appSettings.isDarkMode ? .dark : .light)
    }
}

struct MenuView: View {
    @State private var showingLogoutAlert = false
    @EnvironmentObject var appSettings: AppSettings
    
    // Computed properties to break down complex expressions
    private var backgroundColor: Color {
        if appSettings.isDarkMode {
            return Color.black
        } else {
            return Color(red: 0.77, green: 0.80, blue: 0.79)
        }
    }
    
    private var backgroundOpacity: Double {
        appSettings.isDarkMode ? 1.0 : 0.79
    }
    
    private var textColor: Color {
        appSettings.isDarkMode ? .white : .white
    }
    
    private var capsuleFill: Color {
        appSettings.isDarkMode ? Color.gray.opacity(0.3) : Color.black
    }
    
    private var logoutTextColor: Color {
        appSettings.isDarkMode ? .white : .black
    }
    
    private var logoutButtonFill: Color {
        appSettings.isDarkMode ? Color.red.opacity(0.8) : Color.black
    }
    
    var body: some View {
        ZStack {
            // Background color that adapts to dark mode
            backgroundColor
                .opacity(backgroundOpacity)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Top search bar
                topSearchBar
                
                // Main image with navigation buttons - NOW WITH CROWN BACKGROUND
                mainContentArea
                
                // Bottom logout section
                bottomLogoutSection
                
                // Logo placeholder
                logoPlaceholder
            }
        }
    }
    
    private var topSearchBar: some View {
        HStack {
            Text("King company")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(textColor)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.trailing, 30)
            
            Capsule()
                .fill(capsuleFill)
                .frame(height: 50)
                .overlay(
                    RoundedRectangle(cornerRadius: 25)
                        .stroke(Color(white: 0.91), lineWidth: 1)
                )
                .shadow(color: .black.opacity(0.25), radius: 4, y: 4)
        }
        .padding(.horizontal)
        .padding(.top, 27)
    }
    
    private var mainContentArea: some View {
        ZStack {
            // Crown Background - Enhanced for main page
            MainCrownBackgroundView()
                .frame(maxWidth: 412, maxHeight: 638)
            
            VStack(spacing: 85) {
                navigationButtons
            }
            .padding(.horizontal, 27)
            .padding(.vertical, 50)
        }
    }
    
    private var navigationButtons: some View {
        Group {
            // Subscriptions button (Mail icon)
            NavigationLink(destination: SubscriptionsView()) {
                createNavigationButton(iconName: "envelope.open")
            }
            .buttonStyle(InteractiveButtonStyle())
            
            // Contact Me button (Chat icon)
            NavigationLink(destination: ContactView()) {
                createNavigationButton(iconName: "bubble.left.and.bubble.right")
            }
            .buttonStyle(InteractiveButtonStyle())
            
            // About Me button (Cart icon repurposed)
            NavigationLink(destination: AboutView()) {
                createNavigationButton(iconName: "person.circle")
            }
            .buttonStyle(InteractiveButtonStyle())
            
            // Settings button
            NavigationLink(destination: SettingsView()) {
                createNavigationButton(iconName: "gearshape")
            }
            .buttonStyle(InteractiveButtonStyle())
        }
    }
    
    private func createNavigationButton(iconName: String) -> some View {
        let buttonFill = appSettings.isDarkMode ? Color.gray.opacity(0.8) : Color.black
        
        return Capsule()
            .fill(buttonFill)
            .frame(height: 51)
            .overlay(
                Image(systemName: iconName)
                    .foregroundColor(.white)
                    .font(.title2)
            )
    }
    
    private var bottomLogoutSection: some View {
        HStack {
            Text("log out")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(logoutTextColor)
            
            NavigationLink(destination: LoginView()) {
                Capsule()
                    .fill(logoutButtonFill)
                    .frame(height: 50)
                    .overlay(logoutButtonContent)
                    .shadow(color: .black.opacity(0.25), radius: 4, y: 4)
            }
            .buttonStyle(InteractiveButtonStyle())
        }
        .padding(.horizontal)
        .padding(.top, 50)
    }
    
    private var logoutButtonContent: some View {
        HStack {
            Image(systemName: "rectangle.portrait.and.arrow.right")
                .foregroundColor(.white)
            Spacer()
            Image(systemName: "xmark")
                .foregroundColor(.white)
        }
        .padding(.horizontal)
    }
    
    private var logoPlaceholder: some View {
        Rectangle()
            .fill(Color.gray.opacity(0.3))
            .frame(width: 46, height: 72)
            .overlay(
                Text("LOGO")
                    .font(.caption)
                    .foregroundColor(.gray)
            )
            .rotationEffect(Angle(degrees: -0.38))
            .padding(.trailing)
            .frame(maxWidth: .infinity, alignment: .trailing)
    }
}

// Enhanced Main Crown Background View for the main navigation page
struct MainCrownBackgroundView: View {
    @State private var animationOffset: CGFloat = 0
    @EnvironmentObject var appSettings: AppSettings
    
    // Pre-computed values to avoid complex expressions
    private let crownPositions: [(x: CGFloat, y: CGFloat)] = [
        (100, 150), (250, 180), (180, 280), (320, 250),
        (80, 350), (280, 380), (150, 450), (220, 320)
    ]
    
    private let crownSizes: [CGFloat] = [80, 120, 90, 110, 100, 95, 85, 105]
    private let crownOpacities: [Double] = [0.08, 0.12, 0.09, 0.11, 0.07, 0.10, 0.06, 0.13]
    private let crownRotations: [Double] = [-15, 10, -20, 25, -10, 15, -25, 20]
    
    private let sparklePositions: [(x: CGFloat, y: CGFloat)] = [
        (120, 180), (280, 160), (200, 220), (350, 190), (90, 280),
        (320, 290), (180, 350), (250, 380), (140, 420), (300, 450),
        (110, 320), (270, 340), (190, 380), (330, 410), (160, 480),
        (290, 500), (220, 520), (350, 530), (130, 550), (280, 580)
    ]
    
    // Computed properties for colors
    private var gradientColors: [Color] {
        if appSettings.isDarkMode {
            return [
                Color.purple.opacity(0.3),
                Color.blue.opacity(0.2),
                Color.indigo.opacity(0.15)
            ]
        } else {
            return [
                Color.purple.opacity(0.15),
                Color.blue.opacity(0.1),
                Color.indigo.opacity(0.05)
            ]
        }
    }
    
    private var centralCrownOpacity: Double {
        appSettings.isDarkMode ? 0.2 : 0.12
    }
    
    var body: some View {
        ZStack {
            backgroundGradient
            floatingCrowns
            centralCrown
            sparkleEffects
        }
        .onAppear {
            animationOffset = 360
        }
    }
    
    private var backgroundGradient: some View {
        LinearGradient(
            gradient: Gradient(colors: gradientColors),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var floatingCrowns: some View {
        ForEach(0..<8, id: \.self) { index in
            FloatingCrown(
                size: crownSizes[index],
                opacity: crownOpacities[index],
                rotationAngle: crownRotations[index],
                animationDelay: Double(index) * 0.5,
                isDarkMode: appSettings.isDarkMode
            )
            .position(x: crownPositions[index].x, y: crownPositions[index].y)
        }
    }
    
    private var centralCrown: some View {
        CrownSilhouette()
            .frame(width: 220, height: 220)
            .opacity(centralCrownOpacity)
            .scaleEffect(1.3)
            .rotationEffect(.degrees(animationOffset * 0.1))
            .animation(.linear(duration: 20).repeatForever(autoreverses: false), value: animationOffset)
    }
    
    private var sparkleEffects: some View {
        ForEach(0..<20, id: \.self) { index in
            SparkleView(isDarkMode: appSettings.isDarkMode)
                .position(x: sparklePositions[index].x, y: sparklePositions[index].y)
        }
    }
}

// Floating Crown component
struct FloatingCrown: View {
    let size: CGFloat
    let opacity: Double
    let rotationAngle: Double
    let animationDelay: Double
    let isDarkMode: Bool
    
    @State private var isFloating = false
    @State private var rotationOffset: Double = 0
    
    // Pre-computed values
    private let floatingDuration: Double = [3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0].randomElement() ?? 4.0
    private let rotationDuration: Double = [10.0, 12.0, 15.0, 18.0, 20.0].randomElement() ?? 15.0
    
    private var finalOpacity: Double {
        isDarkMode ? opacity * 1.5 : opacity
    }
    
    var body: some View {
        CrownSilhouette()
            .frame(width: size, height: size)
            .opacity(finalOpacity)
            .rotationEffect(.degrees(rotationAngle + rotationOffset))
            .offset(y: isFloating ? -20 : 20)
            .animation(.easeInOut(duration: floatingDuration).repeatForever(autoreverses: true), value: isFloating)
            .onAppear {
                startAnimations()
            }
    }
    
    private func startAnimations() {
        DispatchQueue.main.asyncAfter(deadline: .now() + animationDelay) {
            isFloating.toggle()
            withAnimation(.linear(duration: rotationDuration).repeatForever(autoreverses: false)) {
                rotationOffset = 360
            }
        }
    }
}

// ENHANCED SUBSCRIPTIONS VIEW - INTEGRATED FROM SUBSCRIPTION VIEW
struct SubscriptionsView: View {
    @State private var selectedMembership: MembershipType? = nil
    @State private var searchText = ""
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var appSettings: AppSettings
    
    enum MembershipType: String, CaseIterable {
        case gold = "Gold"
        case silver = "Silver"
        case bronze = "Bronze"
        
        var color: Color {
            switch self {
            case .gold: return Color.yellow
            case .silver: return Color.gray
            case .bronze: return Color.orange
            }
        }
        
        var description: String {
            switch self {
            case .gold: return "Premium benefits and exclusive access"
            case .silver: return "Great value with enhanced features"
            case .bronze: return "Essential membership with core benefits"
            }
        }
        
        var price: String {
            switch self {
            case .gold: return "$29.99/month"
            case .silver: return "$19.99/month"
            case .bronze: return "$9.99/month"
            }
        }
        
        var features: [String] {
            switch self {
            case .gold: return ["Priority Support", "Exclusive Content", "Advanced Features"]
            case .silver: return ["Standard Support", "Premium Content", "Enhanced Features"]
            case .bronze: return ["Basic Support", "Standard Content", "Core Features"]
            }
        }
    }
    
    // Computed properties to break down complex expressions
    private var backgroundColor: Color {
        if appSettings.isDarkMode {
            return Color.black
        } else {
            return Color(red: 0.77, green: 0.80, blue: 0.79)
        }
    }
    
    private var backgroundOpacity: Double {
        appSettings.isDarkMode ? 1.0 : 0.79
    }
    
    private var searchBarFill: Color {
        appSettings.isDarkMode ? Color.gray.opacity(0.3) : Color.black
    }
    
    private var titleColor: Color {
        appSettings.isDarkMode ? .white : .black
    }
    
    private var selectedMembershipTextColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .black.opacity(0.7)
    }
    
    private var scrollViewBackground: Color {
        let baseColor = appSettings.isDarkMode ? Color.gray.opacity(0.1) : Color.black.opacity(0.05)
        return baseColor
    }
    
    private var scrollViewStroke: Color {
        let baseColor = appSettings.isDarkMode ? Color.white.opacity(0.2) : Color.black.opacity(0.2)
        return baseColor
    }
    
    var body: some View {
        ZStack {
            // Background that adapts to dark mode
            backgroundColor
                .opacity(backgroundOpacity)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Enhanced Search Bar
                searchBarSection
                
                titleSection
                
                selectedMembershipInfo
                
                // Main Content Area with ScrollView
                mainScrollView
                
                Spacer(minLength: 20)
                
                // Enhanced Action Buttons
                actionButtons
            }
        }
        .navigationBarHidden(true) // Remove the blue back button
    }
    
    private var searchBarSection: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25)
                .fill(searchBarFill)
                .frame(width: 343, height: 50)
                .overlay(
                    RoundedRectangle(cornerRadius: 25)
                        .stroke(Color(white: 0.91), lineWidth: 1)
                )
                .shadow(color: Color.black.opacity(0.25), radius: 4, y: 4)
            
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.white.opacity(0.7))
                    .padding(.leading, 20)
                
                TextField("Search memberships...", text: $searchText)
                    .foregroundColor(.white)
                    .font(.system(size: 16, weight: .medium))
                    .textFieldStyle(PlainTextFieldStyle())
                    .placeholder(when: searchText.isEmpty) {
                        Text("Search memberships...")
                            .foregroundColor(.white.opacity(0.5))
                            .font(.system(size: 16, weight: .medium))
                    }
                
                Text("King Company")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.white.opacity(0.8))
                    .padding(.trailing, 20)
            }
        }
        .padding(.top, 27)
    }
    
    private var titleSection: some View {
        Text("Memberships")
            .font(.system(size: 30, weight: .bold))
            .foregroundColor(titleColor)
            .padding(.top, 30)
    }
    
    @ViewBuilder
    private var selectedMembershipInfo: some View {
        if let selected = selectedMembership {
            HStack {
                Text("Selected: \(selected.rawValue)")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(selectedMembershipTextColor)
                
                Text(selected.price)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(selected.color)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 4)
                    .background(selected.color.opacity(0.2))
                    .cornerRadius(12)
            }
            .padding(.top, 10)
        }
    }
    
    private var mainScrollView: some View {
        ScrollView {
            VStack(spacing: 20) {
                ForEach(MembershipType.allCases, id: \.self) { membership in
                    membershipCard(membership: membership)
                }
                
                selectedMembershipDetails
            }
            .padding(.vertical, 20)
        }
        .frame(maxHeight: 450)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(scrollViewBackground)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(scrollViewStroke, lineWidth: 1)
                )
                .shadow(color: Color.black.opacity(0.1), radius: 8, y: 4)
        )
        .padding(.horizontal, 30)
        .padding(.top, 28)
    }
    
    @ViewBuilder
    private var selectedMembershipDetails: some View {
        if let selected = selectedMembership {
            VStack(spacing: 15) {
                Text("Membership Benefits")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(titleColor)
                
                Text(selected.description)
                    .font(.system(size: 16))
                    .foregroundColor(selectedMembershipTextColor)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(selected.features, id: \.self) { feature in
                        HStack {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(selected.color)
                            Text(feature)
                                .font(.system(size: 14))
                                .foregroundColor(selectedMembershipTextColor)
                            Spacer()
                        }
                    }
                }
                .padding()
                .background(featureListBackground)
                .cornerRadius(12)
                .padding(.horizontal, 20)
            }
            .padding(.top, 20)
        }
    }
    
    private var featureListBackground: Color {
        let baseColor = appSettings.isDarkMode ? Color.gray.opacity(0.2) : Color.white
        return baseColor.opacity(0.8)
    }
    
    private var actionButtons: some View {
        VStack(spacing: 15) {
            // Subscribe/Cart Button
            subscribeButton
            
            // Back/Navigation Button - FIXED
            backButton
        }
        .padding(.bottom, 30)
    }
    
    private var subscribeButton: some View {
        Button(action: {
            if let membership = selectedMembership {
                print("Subscribing to \(membership.rawValue) for \(membership.price)")
                // Handle subscription logic
            }
        }) {
            HStack {
                Image(systemName: selectedMembership != nil ? "creditcard.fill" : "cart.fill")
                    .foregroundColor(.white)
                    .font(.system(size: 18))
                
                Text(selectedMembership != nil ? "Subscribe Now" : "Select Membership")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                
                Spacer()
                
                if let selected = selectedMembership {
                    Text(selected.price)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                }
            }
            .frame(width: 343, height: 51)
            .background(subscribeButtonBackground)
            .cornerRadius(25)
            .shadow(color: .black.opacity(0.3), radius: 5, y: 3)
        }
        .disabled(selectedMembership == nil)
        .scaleEffect(selectedMembership != nil ? 1.0 : 0.95)
        .animation(.spring(response: 0.3, dampingFraction: 0.6), value: selectedMembership)
    }
    
    private var subscribeButtonBackground: LinearGradient {
        if let selectedMembership = selectedMembership {
            return LinearGradient(
                gradient: Gradient(colors: [selectedMembership.color.opacity(0.8), Color.black]),
                startPoint: .leading,
                endPoint: .trailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [Color.black.opacity(0.6), Color.black.opacity(0.4)]),
                startPoint: .leading,
                endPoint: .trailing
            )
        }
    }
    
    private var backButton: some View {
        Button(action: {
            presentationMode.wrappedValue.dismiss()
        }) {
            HStack {
                Image(systemName: "arrow.left")
                    .foregroundColor(backButtonTextColor)
                Text("Back to Menu")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(backButtonTextColor)
                Spacer()
            }
            .padding(.horizontal, 30)
        }
    }
    
    private var backButtonTextColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .black.opacity(0.7)
    }
    
    private func membershipCard(membership: MembershipType) -> some View {
        Button(action: {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                selectedMembership = selectedMembership == membership ? nil : membership
            }
            print("\(membership.rawValue) membership selected")
        }) {
            VStack(spacing: 12) {
                HStack {
                    Image(systemName: "crown.fill")
                        .foregroundColor(membership.color)
                        .font(.system(size: 20))
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(membership.rawValue)
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                        
                        Text(membership.price)
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(membership.color)
                    }
                    
                    Spacer()
                    
                    if selectedMembership == membership {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                            .font(.system(size: 22))
                    } else {
                        Image(systemName: "circle")
                            .foregroundColor(.white.opacity(0.5))
                            .font(.system(size: 22))
                    }
                }
                
                if selectedMembership == membership {
                    Text(membership.description)
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.9))
                        .multilineTextAlignment(.leading)
                        .transition(.opacity.combined(with: .scale))
                }
            }
            .frame(maxWidth: .infinity)
            .padding(20)
            .background(membershipCardBackground(membership: membership))
            .scaleEffect(selectedMembership == membership ? 1.02 : 1.0)
            .shadow(
                color: selectedMembership == membership ? membership.color.opacity(0.4) : Color.black.opacity(0.2),
                radius: selectedMembership == membership ? 8 : 4,
                y: selectedMembership == membership ? 6 : 2
            )
        }
        .padding(.horizontal, 20)
    }
    
    private func membershipCardBackground(membership: MembershipType) -> some View {
        let isSelected = selectedMembership == membership
        
        let gradient: LinearGradient
        if isSelected {
            gradient = LinearGradient(
                gradient: Gradient(colors: [Color.black, membership.color.opacity(0.3)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            gradient = LinearGradient(
                gradient: Gradient(colors: [Color.black.opacity(0.8), Color.black.opacity(0.6)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
        
        return RoundedRectangle(cornerRadius: 16)
            .fill(gradient)
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(
                        isSelected ? membership.color : Color.clear,
                        lineWidth: 2
                    )
            )
    }
}

// Custom Crown Background View (existing implementation)
struct CrownBackgroundView: View {
    @EnvironmentObject var appSettings: AppSettings
    
    private var gradientColors: [Color] {
        if appSettings.isDarkMode {
            return [
                Color.purple.opacity(0.3),
                Color.blue.opacity(0.2),
                Color.indigo.opacity(0.15)
            ]
        } else {
            return [
                Color.purple.opacity(0.15),
                Color.blue.opacity(0.1),
                Color.indigo.opacity(0.05)
            ]
        }
    }
    
    private var crownOpacity1: Double { appSettings.isDarkMode ? 0.16 : 0.08 }
    private var crownOpacity2: Double { appSettings.isDarkMode ? 0.12 : 0.06 }
    private var crownOpacity3: Double { appSettings.isDarkMode ? 0.24 : 0.12 }
    private var crownOpacity4: Double { appSettings.isDarkMode ? 0.1 : 0.05 }
    private var crownOpacity5: Double { appSettings.isDarkMode ? 0.14 : 0.07 }
    
    var body: some View {
        ZStack {
            // Elegant background gradient
            LinearGradient(
                gradient: Gradient(colors: gradientColors),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            
            // Multiple crown silhouettes for pattern effect
            VStack(spacing: 100) {
                HStack(spacing: 80) {
                    CrownSilhouette()
                        .frame(width: 120, height: 120)
                        .opacity(crownOpacity1)
                        .rotationEffect(.degrees(-15))
                    
                    CrownSilhouette()
                        .frame(width: 100, height: 100)
                        .opacity(crownOpacity2)
                        .rotationEffect(.degrees(10))
                }
                
                // Main central crown - larger and more prominent
                CrownSilhouette()
                    .frame(width: 200, height: 200)
                    .opacity(crownOpacity3)
                    .scaleEffect(1.2)
                
                HStack(spacing: 90) {
                    CrownSilhouette()
                        .frame(width: 90, height: 90)
                        .opacity(crownOpacity4)
                        .rotationEffect(.degrees(20))
                    
                    CrownSilhouette()
                        .frame(width: 110, height: 110)
                        .opacity(crownOpacity5)
                        .rotationEffect(.degrees(-10))
                }
            }
            .offset(y: -20)
            
            // Subtle sparkle effects
            ForEach(0..<15, id: \.self) { _ in
                SparkleView(isDarkMode: appSettings.isDarkMode)
                    .position(
                        x: CGFloat.random(in: 50...350),
                        y: CGFloat.random(in: 100...500)
                    )
            }
        }
    }
}

// Crown Silhouette Shape
struct CrownSilhouette: View {
    @EnvironmentObject var appSettings: AppSettings
    
    private var gradientColors: [Color] {
        if appSettings.isDarkMode {
            return [
                Color.yellow.opacity(0.6),
                Color.orange.opacity(0.4),
                Color.purple.opacity(0.2)
            ]
        } else {
            return [
                Color.yellow.opacity(0.3),
                Color.orange.opacity(0.2),
                Color.purple.opacity(0.1)
            ]
        }
    }
    
    var body: some View {
        ZStack {
            CrownShape()
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: gradientColors),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
        }
    }
}

// Crown Shape Path (existing implementation)
struct CrownShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.width
        let height = rect.height
        
        // Crown base
        let baseHeight = height * 0.3
        let baseRect = CGRect(x: width * 0.1, y: height * 0.7, width: width * 0.8, height: baseHeight)
        path.addRoundedRect(in: baseRect, cornerSize: CGSize(width: 8, height: 8))
        
        // Crown points (5 points)
        let pointWidth = width * 0.15
        let pointPositions: [CGFloat] = [0.15, 0.3, 0.5, 0.7, 0.85]
        let pointHeights: [CGFloat] = [0.4, 0.6, 0.2, 0.6, 0.4] // Middle point tallest
        
        for (index, xPos) in pointPositions.enumerated() {
            let pointHeight = height * pointHeights[index]
            let pointX = width * xPos
            let pointY = height * 0.7
            
            // Create triangular crown point
            path.move(to: CGPoint(x: pointX - pointWidth/2, y: pointY))
            path.addLine(to: CGPoint(x: pointX, y: pointY - pointHeight))
            path.addLine(to: CGPoint(x: pointX + pointWidth/2, y: pointY))
            path.addLine(to: CGPoint(x: pointX - pointWidth/2, y: pointY))
            
            // Add jewel on each point
            let jewelRadius: CGFloat = 6
            let jewelCenter = CGPoint(x: pointX, y: pointY - pointHeight * 0.7)
            path.addEllipse(in: CGRect(x: jewelCenter.x - jewelRadius, y: jewelCenter.y - jewelRadius,
                                     width: jewelRadius * 2, height: jewelRadius * 2))
        }
        
        return path
    }
}

// Enhanced Sparkle Effect View
struct SparkleView: View {
    @State private var isAnimating = false
    @State private var opacity: Double = 0
    let isDarkMode: Bool
    
    // Pre-computed values to avoid complex expressions
    private let sparkleSize: CGFloat = [8, 10, 12, 14, 16].randomElement() ?? 12
    private let animationDuration: Double = [2.0, 2.5, 3.0, 3.5, 4.0].randomElement() ?? 3.0
    private let opacityRange: Double = [0.3, 0.4, 0.5, 0.6, 0.7, 0.8].randomElement() ?? 0.5
    
    private var sparkleColor: Color {
        .yellow.opacity(isDarkMode ? 0.9 : 0.6)
    }
    
    var body: some View {
        Image(systemName: "sparkle")
            .font(.system(size: sparkleSize))
            .foregroundColor(sparkleColor)
            .opacity(opacity)
            .scaleEffect(isAnimating ? 1.2 : 0.8)
            .onAppear {
                startAnimations()
            }
    }
    
    private func startAnimations() {
        withAnimation(.easeInOut(duration: animationDuration).repeatForever(autoreverses: true)) {
            isAnimating.toggle()
        }
        
        let opacityDuration = [1.0, 1.5, 2.0, 2.5, 3.0].randomElement() ?? 2.0
        withAnimation(.easeInOut(duration: opacityDuration).repeatForever(autoreverses: true)) {
            opacity = opacityRange
        }
    }
}

// Interactive button style with animations
struct InteractiveButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
            .animation(.easeInOut(duration: 0.1), value: configuration.isPressed)
    }
}

// Extension for TextField placeholder
extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content) -> some View {

        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}

// Contact Page - Updated for dark mode WITH BACK BUTTON
struct ContactView: View {
    @State private var name = ""
    @State private var email = ""
    @State private var message = ""
    @State private var showingAlert = false
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var appSettings: AppSettings
    
    private var backgroundGradient: LinearGradient {
        if appSettings.isDarkMode {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color.gray.opacity(0.3)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.green.opacity(0.1),
                    Color.blue.opacity(0.1)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    private var titleColor: Color {
        appSettings.isDarkMode ? .white : .primary
    }
    
    private var sectionBackgroundColor: Color {
        let baseColor = appSettings.isDarkMode ? Color.gray.opacity(0.1) : Color.white.opacity(0.1)
        return baseColor
    }
    
    private var backButtonTextColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .black.opacity(0.7)
    }
    
    var body: some View {
        ZStack {
            backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                ScrollView {
                    VStack(spacing: 25) {
                        Text("Contact Me")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(titleColor)
                            .padding(.top)
                        
                        VStack(spacing: 20) {
                            CustomTextField(text: $name, placeholder: "Your Name", icon: "person")
                            CustomTextField(text: $email, placeholder: "Email Address", icon: "envelope")
                            
                            messageSection
                            
                            sendButton
                        }
                        .padding()
                        .background(sectionBackgroundColor)
                        .cornerRadius(16)
                        
                        Spacer(minLength: 50)
                    }
                    .padding()
                }
                
                // Back Button at bottom
                backButton
                    .padding(.bottom, 30)
            }
        }
        .navigationBarHidden(true)
        .alert("Message Sent!", isPresented: $showingAlert) {
            Button("OK") {
                name = ""
                email = ""
                message = ""
            }
        } message: {
            Text("Thank you for your message. I'll get back to you soon!")
        }
    }
    
    private var messageSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "bubble.left.and.bubble.right")
                    .foregroundColor(.blue)
                Text("Message")
                    .font(.headline)
                    .foregroundColor(titleColor)
            }
            
            TextEditor(text: $message)
                .frame(minHeight: 120)
                .padding(12)
                .background(textEditorBackground)
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                )
        }
    }
    
    private var textEditorBackground: Color {
        let baseColor = appSettings.isDarkMode ? Color.gray.opacity(0.2) : Color.white
        return baseColor.opacity(0.8)
    }
    
    private var sendButton: some View {
        Button(action: {
            showingAlert = true
        }) {
            HStack {
                Image(systemName: "paperplane.fill")
                Text("Send Message")
                    .fontWeight(.semibold)
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding()
            .background(sendButtonBackground)
            .cornerRadius(12)
        }
        .buttonStyle(InteractiveButtonStyle())
        .disabled(name.isEmpty || email.isEmpty || message.isEmpty)
        .opacity(name.isEmpty || email.isEmpty || message.isEmpty ? 0.6 : 1.0)
    }
    
    private var sendButtonBackground: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [Color.blue, Color.purple]),
            startPoint: .leading,
            endPoint: .trailing
        )
    }
    
    private var backButton: some View {
        Button(action: {
            presentationMode.wrappedValue.dismiss()
        }) {
            HStack {
                Image(systemName: "arrow.left")
                    .foregroundColor(backButtonTextColor)
                Text("Back to Menu")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(backButtonTextColor)
                Spacer()
            }
            .padding(.horizontal, 30)
        }
    }
}

struct CustomTextField: View {
    @Binding var text: String
    let placeholder: String
    let icon: String
    @EnvironmentObject var appSettings: AppSettings
    
    private var titleColor: Color {
        appSettings.isDarkMode ? .white : .primary
    }
    
    private var textFieldBackground: Color {
        let baseColor = appSettings.isDarkMode ? Color.gray.opacity(0.2) : Color.white
        return baseColor.opacity(0.8)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(.blue)
                Text(placeholder)
                    .font(.headline)
                    .foregroundColor(titleColor)
            }
            
            TextField(placeholder, text: $text)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal, 12)
                .padding(.vertical, 12)
                .background(textFieldBackground)
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                )
        }
    }
}

// About Page - Updated for dark mode WITH BACK BUTTON
struct AboutView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var appSettings: AppSettings
    
    private var backgroundGradient: LinearGradient {
        if appSettings.isDarkMode {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color.gray.opacity(0.3)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.orange.opacity(0.1),
                    Color.red.opacity(0.1)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    private var titleColor: Color {
        appSettings.isDarkMode ? .white : .primary
    }
    
    private var profileSectionBackground: Color {
        let baseColor = appSettings.isDarkMode ? Color.gray.opacity(0.2) : Color.white
        return baseColor.opacity(0.8)
    }
    
    private var profileCircleGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [Color.orange, Color.red]),
            startPoint: .top,
            endPoint: .bottom
        )
    }
    
    private var subtitleColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .secondary
    }
    
    private var backButtonTextColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .black.opacity(0.7)
    }
    
    var body: some View {
        ZStack {
            backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                ScrollView {
                    VStack(spacing: 25) {
                        Text("About Me")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(titleColor)
                            .padding(.top)
                        
                        // Profile section
                        profileSection
                        
                        // Info cards
                        infoCardsSection
                        
                        Spacer(minLength: 50)
                    }
                    .padding()
                }
                
                // Back Button at bottom
                backButton
                    .padding(.bottom, 30)
            }
        }
        .navigationBarHidden(true)
    }
    
    private var profileSection: some View {
        VStack(spacing: 15) {
            Circle()
                .fill(profileCircleGradient)
                .frame(width: 120, height: 120)
                .overlay(
                    Image(systemName: "person.fill")
                        .font(.system(size: 50))
                        .foregroundColor(.white)
                )
            
            Text("King Company")
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(titleColor)
            
            Text("Innovative Solutions Provider")
                .font(.subheadline)
                .foregroundColor(subtitleColor)
        }
        .padding()
        .background(profileSectionBackground)
        .cornerRadius(16)
    }
    
    private var infoCardsSection: some View {
        VStack(spacing: 15) {
            InfoCard(
                icon: "lightbulb.fill",
                title: "Mission",
                description: "To provide innovative solutions that empower businesses and individuals to achieve their goals.",
                color: .yellow
            )
            
            InfoCard(
                icon: "target",
                title: "Vision",
                description: "Creating a world where technology seamlessly integrates with human needs.",
                color: .green
            )
            
            InfoCard(
                icon: "heart.fill",
                title: "Values",
                description: "Innovation, integrity, and customer satisfaction drive everything we do.",
                color: .pink
            )
        }
    }
    
    private var backButton: some View {
        Button(action: {
            presentationMode.wrappedValue.dismiss()
        }) {
            HStack {
                Image(systemName: "arrow.left")
                    .foregroundColor(backButtonTextColor)
                Text("Back to Menu")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(backButtonTextColor)
                Spacer()
            }
            .padding(.horizontal, 30)
        }
    }
}

struct InfoCard: View {
    let icon: String
    let title: String
    let description: String
    let color: Color
    @EnvironmentObject var appSettings: AppSettings
    
    private var titleColor: Color {
        appSettings.isDarkMode ? .white : .primary
    }
    
    private var descriptionColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .secondary
    }
    
    private var cardBackground: Color {
        let baseColor = appSettings.isDarkMode ? Color.gray.opacity(0.2) : Color.white
        return baseColor.opacity(0.8)
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Circle()
                .fill(color.opacity(0.2))
                .frame(width: 50, height: 50)
                .overlay(
                    Image(systemName: icon)
                        .foregroundColor(color)
                        .font(.title3)
                )
            
            VStack(alignment: .leading, spacing: 8) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(titleColor)
                
                Text(description)
                    .font(.body)
                    .foregroundColor(descriptionColor)
                    .multilineTextAlignment(.leading)
            }
            
            Spacer()
        }
        .padding()
        .background(cardBackground)
        .cornerRadius(12)
    }
}

// Settings Page - Updated with working dark mode toggle WITH BACK BUTTON
struct SettingsView: View {
    @State private var notificationsEnabled = true
    @State private var autoSyncEnabled = true
    @State private var selectedLanguage = "English"
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var appSettings: AppSettings
    
    let languages = ["English", "Spanish", "French", "German", "Chinese"]
    
    private var backgroundGradient: LinearGradient {
        if appSettings.isDarkMode {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color.gray.opacity(0.3)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.gray.opacity(0.1),
                    Color.blue.opacity(0.1)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    private var titleColor: Color {
        appSettings.isDarkMode ? .white : .primary
    }
    
    private var backButtonTextColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .black.opacity(0.7)
    }
    
    var body: some View {
        ZStack {
            backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                ScrollView {
                    VStack(spacing: 25) {
                        Text("Settings")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(titleColor)
                            .padding(.top)
                        
                        // Preferences section
                        preferencesSection
                        
                        // Account section
                        accountSection
                        
                        Spacer(minLength: 50)
                    }
                    .padding()
                }
                
                // Back Button at bottom
                backButton
                    .padding(.bottom, 30)
            }
        }
        .navigationBarHidden(true)
    }
    
    private var preferencesSection: some View {
        SettingsSection(title: "Preferences") {
            SettingsToggle(
                title: "Push Notifications",
                description: "Receive updates and alerts",
                isOn: $notificationsEnabled,
                icon: "bell.fill",
                color: .blue
            )
            
            SettingsToggle(
                title: "Dark Mode",
                description: "Use dark appearance",
                isOn: $appSettings.isDarkMode,
                icon: "moon.fill",
                color: .purple
            )
            
            SettingsToggle(
                title: "Auto Sync",
                description: "Sync data automatically",
                isOn: $autoSyncEnabled,
                icon: "arrow.clockwise",
                color: .green
            )
        }
    }
    
    private var accountSection: some View {
        SettingsSection(title: "Account") {
            SettingsRow(
                title: "Language",
                value: selectedLanguage,
                icon: "globe",
                color: .orange
            ) {
                // Language selection action
            }
            
            SettingsRow(
                title: "Privacy Policy",
                icon: "lock.shield",
                color: .red
            ) {
                // Privacy policy action
            }
            
            SettingsRow(
                title: "Terms of Service",
                icon: "doc.text",
                color: .gray
            ) {
                // Terms action
            }
        }
    }
    
    private var backButton: some View {
        Button(action: {
            presentationMode.wrappedValue.dismiss()
        }) {
            HStack {
                Image(systemName: "arrow.left")
                    .foregroundColor(backButtonTextColor)
                Text("Back to Menu")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(backButtonTextColor)
                Spacer()
            }
            .padding(.horizontal, 30)
        }
    }
}

struct SettingsSection<Content: View>: View {
    let title: String
    let content: Content
    @EnvironmentObject var appSettings: AppSettings
    
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    private var titleColor: Color {
        appSettings.isDarkMode ? .white : .primary
    }
    
    private var sectionBackground: Color {
        let baseColor = appSettings.isDarkMode ? Color.gray.opacity(0.2) : Color.white
        return baseColor.opacity(0.8)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text(title)
                .font(.headline)
                .foregroundColor(titleColor)
                .padding(.horizontal)
            
            VStack(spacing: 1) {
                content
            }
            .background(sectionBackground)
            .cornerRadius(12)
        }
    }
}

struct SettingsToggle: View {
    let title: String
    let description: String
    @Binding var isOn: Bool
    let icon: String
    let color: Color
    @EnvironmentObject var appSettings: AppSettings
    
    private var titleColor: Color {
        appSettings.isDarkMode ? .white : .primary
    }
    
    private var descriptionColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .secondary
    }
    
    var body: some View {
        HStack(spacing: 15) {
            Circle()
                .fill(color.opacity(0.2))
                .frame(width: 40, height: 40)
                .overlay(
                    Image(systemName: icon)
                        .foregroundColor(color)
                        .font(.system(size: 18))
                )
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body)
                    .foregroundColor(titleColor)
                
                Text(description)
                    .font(.caption)
                    .foregroundColor(descriptionColor)
            }
            
            Spacer()
            
            Toggle("", isOn: $isOn)
                .toggleStyle(SwitchToggleStyle(tint: color))
        }
        .padding()
    }
}

struct SettingsRow: View {
    let title: String
    let value: String?
    let icon: String
    let color: Color
    let action: () -> Void
    @EnvironmentObject var appSettings: AppSettings
    
    init(title: String, value: String? = nil, icon: String, color: Color, action: @escaping () -> Void) {
        self.title = title
        self.value = value
        self.icon = icon
        self.color = color
        self.action = action
    }
    
    private var titleColor: Color {
        appSettings.isDarkMode ? .white : .primary
    }
    
    private var valueColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .secondary
    }
    
    private var chevronColor: Color {
        appSettings.isDarkMode ? .white.opacity(0.7) : .secondary
    }
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 15) {
                Circle()
                    .fill(color.opacity(0.2))
                    .frame(width: 40, height: 40)
                    .overlay(
                        Image(systemName: icon)
                            .foregroundColor(color)
                            .font(.system(size: 18))
                    )
                
                Text(title)
                    .font(.body)
                    .foregroundColor(titleColor)
                
                Spacer()
                
                if let value = value {
                    Text(value)
                        .font(.caption)
                        .foregroundColor(valueColor)
                }
                
                Image(systemName: "chevron.right")
                    .foregroundColor(chevronColor)
                    .font(.caption)
            }
            .padding()
            .contentShape(Rectangle())
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// Placeholder for LoginView - you'll need to implement this
struct loginView: View {
    var body: some View {
        Text("Login View")
            .font(.largeTitle)
            .navigationBarHidden(true)
    }
}

#Preview {
    Navbar()
}
