//  SwiftUIView.swift
//  Userauth
//
//  Created by Tarik Eddins on 7/30/25.
//

import SwiftUI
import FirebaseAuth

struct SwiftUIView: View {
    @State private var navigateToLogin = false
    @State private var showingMembership = false
    @State private var hoveredMentorIndex: Int? = nil
    
    var body: some View {
        NavigationView {
            ZStack {
                // Modern gradient background
                LinearGradient(
                    colors: [
                        Color(red: 0.1, green: 0.1, blue: 0.2),
                        Color(red: 0.2, green: 0.2, blue: 0.3),
                        Color(red: 0.15, green: 0.15, blue: 0.25)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Modern top navigation bar
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("King Company")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                            
                            Text("Mentorship Platform")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.white.opacity(0.7))
                        }
                        
                        Spacer()
                        
                        NavigationLink(destination: MenuView()) {
                            ZStack {
                                Circle()
                                    .fill(.ultraThinMaterial)
                                    .frame(width: 44, height: 44)
                                
                                Image(systemName: "person.circle.fill")
                                    .font(.system(size: 22))
                                    .foregroundColor(.white)
                            }
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(.ultraThinMaterial)
                            .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
                    )
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    
                    // Enhanced title section
                    VStack(spacing: 8) {
                        Text("Our Mentors")
                            .font(.system(size: 36, weight: .bold, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.white, .white.opacity(0.8)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                        
                        Text("Connect with industry experts")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.white.opacity(0.7))
                    }
                    .padding(.top, 30)
                    
                    // Scrollable mentors grid
                    ScrollView(.vertical, showsIndicators: false) {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 20), count: 3), spacing: 24) {
                            ForEach(0..<12, id: \.self) { index in
                                MentorCircleView(
                                    index: index,
                                    isHovered: hoveredMentorIndex == index
                                )
                                .onHover { isHovering in
                                    withAnimation(.easeInOut(duration: 0.2)) {
                                        hoveredMentorIndex = isHovering ? index : nil
                                    }
                                }
                                .onTapGesture {
                                    // Handle mentor selection
                                    print("Selected mentor \(index)")
                                }
                            }
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 40)
                        .padding(.bottom, 120) // Space for bottom bar
                    }
                    
                    Spacer()
                }
                
                // Floating bottom navigation bar
                VStack {
                    Spacer()
                    
                    HStack(spacing: 0) {
                        Button(action: {
                            signOutAndNavigate()
                        }) {
                            HStack(spacing: 12) {
                                ZStack {
                                    Circle()
                                        .fill(Color.red.opacity(0.2))
                                        .frame(width: 36, height: 36)
                                    
                                    Image(systemName: "power")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundColor(.red)
                                }
                                
                                Text("Logout")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                        }
                        
                        Spacer()
                        
                        NavigationLink(destination: MenuView()) {
                            HStack(spacing: 12) {
                                ZStack {
                                    Circle()
                                        .fill(Color.blue.opacity(0.2))
                                        .frame(width: 36, height: 36)
                                    
                                    Image(systemName: "line.3.horizontal")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundColor(.blue)
                                }
                                
                                Text("Menu")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                        }
                    }
                    .padding(.horizontal, 28)
                    .padding(.vertical, 20)
                    .background(
                        RoundedRectangle(cornerRadius: 25)
                            .fill(.ultraThinMaterial)
                            .shadow(color: .black.opacity(0.2), radius: 20, x: 0, y: 10)
                    )
                    .padding(.horizontal, 20)
                    .padding(.bottom, 30)
                }
            }
            .navigationBarHidden(true)
            .background(
                NavigationLink(destination: LoginView(), isActive: $navigateToLogin) {
                    EmptyView()
                }
                .hidden()
            )
        }
        .environmentObject(AppSettings())
    }
    
    // MARK: - Logout Function
    private func signOutAndNavigate() {
        do {
            try Auth.auth().signOut()
            navigateToLogin = true
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
    }
}

// MARK: - Mentor Circle View Component
struct MentorCircleView: View {
    let index: Int
    let isHovered: Bool
    
    // Sample mentor data - replace with your actual data model
    private var mentorColors: [Color] {
        [.blue, .purple, .green, .orange, .pink, .teal, .indigo, .mint, .cyan, .yellow, .red, .brown]
    }
    
    private var mentorInitials: [String] {
        ["JD", "SM", "AR", "MK", "LB", "TC", "RJ", "NK", "PW", "EM", "GH", "DF"]
    }
    
    var body: some View {
        ZStack {
            // Background circle with gradient
            Circle()
                .fill(
                    LinearGradient(
                        colors: [
                            mentorColors[index % mentorColors.count],
                            mentorColors[index % mentorColors.count].opacity(0.7)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: isHovered ? 85 : 75, height: isHovered ? 85 : 75)
                .shadow(
                    color: mentorColors[index % mentorColors.count].opacity(0.4),
                    radius: isHovered ? 15 : 8,
                    x: 0,
                    y: isHovered ? 8 : 4
                )
            
            // Mentor initials or icon
            if index < mentorInitials.count {
                Text(mentorInitials[index])
                    .font(.system(size: isHovered ? 22 : 18, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
            } else {
                Image(systemName: "person.fill")
                    .font(.system(size: isHovered ? 28 : 24))
                    .foregroundColor(.white)
            }
            
            // Hover effect ring
            if isHovered {
                Circle()
                    .stroke(
                        LinearGradient(
                            colors: [.white.opacity(0.6), .white.opacity(0.2)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 3
                    )
                    .frame(width: 90, height: 90)
            }
        }
        .scaleEffect(isHovered ? 1.05 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isHovered)
    }
}

#Preview {
    SwiftUIView()
}
