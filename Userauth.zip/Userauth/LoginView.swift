//
//  LoginView.swift
//  Userauth
//
//  Created by Tarik Eddins on 7/1/25.
//

import SwiftUI
import Firebase
import FirebaseAuth

struct LoginView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var isLoading: Bool = false
    @State private var errorMessage: String = ""
    @State private var showingSignUp = false
    @State private var showConfetti = false
    @State private var navigateToMain = false
    @State private var navigateToSignupView = false
    
    // Hover states
    @State private var isLoginButtonHovered = false
    @State private var isForgotPasswordHovered = false
    @State private var isSignUpButtonHovered = false
    @State private var isShowPasswordHovered = false
    
    var body: some View {
        NavigationView {
            ZStack {
                // Modern gradient background matching mentors page
                LinearGradient(
                    colors: [
                        Color(red: 0.1, green: 0.1, blue: 0.2),
                        Color(red: 0.2, green: 0.2, blue: 0.3),
                        Color(red: 0.15, green: 0.15, blue: 0.25)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                // Animated crowns background
                AnimatedCrownsView()
                
                // Background Image
                VStack {
                    Spacer()
                    Image("vro")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(height: 400)
                        .clipped()
                        .opacity(0.3)
                }
                .ignoresSafeArea(edges: .bottom)
                
                // Confetti Effect
                if showConfetti {
                    ConfettiView()
                }
                
                ScrollView {
                    VStack(spacing: 32) {
                        // Modern title section
                        VStack(spacing: 12) {
                            Text("Welcome Back")
                                .font(.system(size: 42, weight: .bold, design: .rounded))
                                .foregroundStyle(
                                    LinearGradient(
                                        colors: [.white, .white.opacity(0.8)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                            
                            Text("Sign in to continue your journey")
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.white.opacity(0.7))
                        }
                        .padding(.top, 60)
                        
                        // Modern input fields container
                        VStack(spacing: 24) {
                            // Email Input
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Email Address")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.8))
                                    .padding(.leading, 4)
                                
                                ZStack {
                                    RoundedRectangle(cornerRadius: 16)
                                        .fill(.ultraThinMaterial)
                                        .frame(height: 56)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 16)
                                                .stroke(.white.opacity(0.2), lineWidth: 1)
                                        )
                                    
                                    HStack {
                                        Image(systemName: "envelope")
                                            .foregroundColor(.white.opacity(0.6))
                                            .font(.system(size: 16))
                                        
                                        TextField("Enter your email", text: $email)
                                            .font(.system(size: 16, weight: .medium))
                                            .foregroundColor(.white)
                                            .autocapitalization(.none)
                                            .keyboardType(.emailAddress)
                                    }
                                    .padding(.horizontal, 16)
                                }
                            }
                            
                            // Password Input
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Password")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.8))
                                    .padding(.leading, 4)
                                
                                ZStack {
                                    RoundedRectangle(cornerRadius: 16)
                                        .fill(.ultraThinMaterial)
                                        .frame(height: 56)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 16)
                                                .stroke(.white.opacity(0.2), lineWidth: 1)
                                        )
                                    
                                    HStack {
                                        Image(systemName: "lock")
                                            .foregroundColor(.white.opacity(0.6))
                                            .font(.system(size: 16))
                                        
                                        if isPasswordVisible {
                                            TextField("Enter your password", text: $password)
                                        } else {
                                            SecureField("Enter your password", text: $password)
                                        }
                                        
                                        Button(action: {
                                            withAnimation(.easeInOut(duration: 0.2)) {
                                                isPasswordVisible.toggle()
                                            }
                                        }) {
                                            Image(systemName: isPasswordVisible ? "eye.slash" : "eye")
                                                .foregroundColor(.white.opacity(0.6))
                                                .font(.system(size: 16))
                                                .scaleEffect(isShowPasswordHovered ? 1.1 : 1.0)
                                                .animation(.easeInOut(duration: 0.2), value: isShowPasswordHovered)
                                        }
                                        .onHover { hovering in
                                            withAnimation(.easeInOut(duration: 0.2)) {
                                                isShowPasswordHovered = hovering
                                            }
                                        }
                                    }
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 16)
                                }
                            }
                        }
                        .padding(.horizontal, 24)
                        
                        // Error Message
                        if !errorMessage.isEmpty {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .font(.system(size: 14, weight: .medium))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 24)
                                .padding(.vertical, 8)
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(.red.opacity(0.1))
                                        .stroke(.red.opacity(0.3), lineWidth: 1)
                                )
                                .padding(.horizontal, 24)
                        }
                        
                        // Modern Login Button
                        Button(action: {
                            signIn()
                        }) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(
                                        LinearGradient(
                                            colors: [
                                                Color.blue,
                                                Color.blue.opacity(0.8),
                                                Color.purple.opacity(0.6)
                                            ],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        )
                                    )
                                    .frame(height: 56)
                                    .shadow(
                                        color: .blue.opacity(isLoginButtonHovered ? 0.4 : 0.2),
                                        radius: isLoginButtonHovered ? 20 : 10,
                                        x: 0,
                                        y: isLoginButtonHovered ? 8 : 4
                                    )
                                    .scaleEffect(isLoginButtonHovered ? 1.02 : 1.0)
                                
                                if isLoading {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                        .scaleEffect(1.2)
                                } else {
                                    HStack(spacing: 12) {
                                        Image(systemName: "arrow.right.circle.fill")
                                            .font(.system(size: 20))
                                        
                                        Text("Sign In")
                                            .font(.system(size: 18, weight: .semibold))
                                    }
                                    .foregroundColor(.white)
                                }
                            }
                        }
                        .disabled(isLoading || email.isEmpty || password.isEmpty)
                        .opacity((isLoading || email.isEmpty || password.isEmpty) ? 0.6 : 1.0)
                        .padding(.horizontal, 24)
                        .padding(.top, 8)
                        .onHover { hovering in
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                isLoginButtonHovered = hovering
                            }
                        }
                        
                        // Action buttons
                        VStack(spacing: 20) {
                            Button(action: {
                                forgotPassword()
                            }) {
                                HStack(spacing: 8) {
                                    Image(systemName: "questionmark.circle")
                                        .font(.system(size: 16))
                                    
                                    Text("Forgot your password?")
                                        .font(.system(size: 16, weight: .semibold))
                                }
                                .foregroundColor(.white.opacity(0.8))
                                .padding(.vertical, 12)
                                .padding(.horizontal, 20)
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(.ultraThinMaterial)
                                        .opacity(isForgotPasswordHovered ? 0.8 : 0.4)
                                )
                                .scaleEffect(isForgotPasswordHovered ? 1.05 : 1.0)
                            }
                            .onHover { hovering in
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    isForgotPasswordHovered = hovering
                                }
                            }
                            
                            // Divider
                            HStack {
                                Rectangle()
                                    .fill(.white.opacity(0.3))
                                    .frame(height: 1)
                                
                                Text("or")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(.white.opacity(0.6))
                                    .padding(.horizontal, 16)
                                
                                Rectangle()
                                    .fill(.white.opacity(0.3))
                                    .frame(height: 1)
                            }
                            .padding(.horizontal, 24)
                            
                            // Sign Up Button
                            Button(action: {
                                navigateToSignupView = true
                            }) {
                                HStack(spacing: 8) {
                                    Image(systemName: "person.badge.plus")
                                        .font(.system(size: 16))
                                    
                                    Text("Create New Account")
                                        .font(.system(size: 16, weight: .semibold))
                                }
                                .foregroundColor(.white)
                                .padding(.vertical, 16)
                                .padding(.horizontal, 24)
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(
                                            LinearGradient(
                                                colors: [.white.opacity(0.4), .white.opacity(0.2)],
                                                startPoint: .topLeading,
                                                endPoint: .bottomTrailing
                                            ),
                                            lineWidth: 2
                                        )
                                        .background(
                                            RoundedRectangle(cornerRadius: 12)
                                                .fill(.ultraThinMaterial.opacity(isSignUpButtonHovered ? 0.3 : 0.1))
                                        )
                                )
                                .scaleEffect(isSignUpButtonHovered ? 1.02 : 1.0)
                                .shadow(
                                    color: .white.opacity(isSignUpButtonHovered ? 0.2 : 0.1),
                                    radius: isSignUpButtonHovered ? 15 : 5,
                                    x: 0,
                                    y: isSignUpButtonHovered ? 6 : 2
                                )
                            }
                            .onHover { hovering in
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                    isSignUpButtonHovered = hovering
                                }
                            }
                        }
                        .padding(.top, 16)
                        
                        Spacer(minLength: 50)
                    }
                }
                
                // Navigation Links - working approach
                NavigationLink(destination: SwiftUIView().navigationBarHidden(true), isActive: $navigateToMain) {
                    EmptyView()
                }
                .hidden()
                
                NavigationLink(destination: SignupView().navigationBarHidden(true), isActive: $navigateToSignupView) {
                    EmptyView()
                }
                .hidden()
            }
            .navigationBarHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle()) // Prevents split view on iPad
    }
    
    // MARK: - Authentication Functions
    private func signIn() {
        guard !email.isEmpty, !password.isEmpty else {
            errorMessage = "Please fill in all fields"
            return
        }
        
        guard isValidEmail(email) else {
            errorMessage = "Please enter a valid email address"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            DispatchQueue.main.async {
                isLoading = false
                
                if let error = error {
                    errorMessage = getErrorMessage(from: error)
                } else {
                    // Login successful - show confetti and navigate
                    showConfetti = true
                    
                    // Navigate to main view after confetti animation
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        print("Attempting to navigate to SwiftUIView")
                        navigateToMain = true
                        print("navigateToMain set to: \(navigateToMain)")
                    }
                }
            }
        }
    }
    
    private func forgotPassword() {
        guard !email.isEmpty else {
            errorMessage = "Please enter your email address first"
            return
        }
        
        guard isValidEmail(email) else {
            errorMessage = "Please enter a valid email address"
            return
        }
        
        Auth.auth().sendPasswordReset(withEmail: email) { error in
            DispatchQueue.main.async {
                if let error = error {
                    errorMessage = getErrorMessage(from: error)
                } else {
                    errorMessage = "Password reset email sent to \(email)"
                }
            }
        }
    }
    
    // MARK: - Helper Functions
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    private func getErrorMessage(from error: Error) -> String {
        if let authError = error as NSError?, let errorCode = AuthErrorCode(rawValue: authError.code) {
            switch errorCode {
            case .invalidEmail:
                return "Invalid email address"
            case .userNotFound:
                return "No account found with this email"
            case .wrongPassword:
                return "Incorrect password"
            case .userDisabled:
                return "This account has been disabled"
            case .tooManyRequests:
                return "Too many attempts. Please try again later"
            case .networkError:
                return "Network error. Please check your connection"
            default:
                return "Login failed. Please try again"
            }
        }
        return error.localizedDescription
    }
}

// MARK: - Animated Crowns Background View
struct AnimatedCrownsView: View {
    @State private var crownPositions: [CrownPosition] = []
    
    var body: some View {
        ZStack {
            ForEach(crownPositions, id: \.id) { crown in
                Image(systemName: "crown.fill")
                    .font(.system(size: crown.size))
                    .foregroundColor(.yellow.opacity(crown.opacity))
                    .position(x: crown.x, y: crown.y)
                    .rotationEffect(.degrees(crown.rotation))
                    .shadow(color: .yellow.opacity(0.3), radius: 8, x: 2, y: 2)
            }
        }
        .onAppear {
            createCrowns()
            animateCrowns()
        }
    }
    
    private func createCrowns() {
        for _ in 0..<8 {
            let crown = CrownPosition(
                id: UUID(),
                x: CGFloat.random(in: 50...UIScreen.main.bounds.width - 50),
                y: CGFloat.random(in: 100...UIScreen.main.bounds.height),
                size: CGFloat.random(in: 25...45),
                opacity: Double.random(in: 0.15...0.4),
                rotation: Double.random(in: 0...360)
            )
            crownPositions.append(crown)
        }
    }
    
    private func animateCrowns() {
        for i in 0..<crownPositions.count {
            let duration = Double.random(in: 3.0...6.0)
            let delay = Double.random(in: 0...2.0)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                animateCrown(at: i, duration: duration)
            }
        }
    }
    
    private func animateCrown(at index: Int, duration: Double) {
        withAnimation(.easeInOut(duration: duration).repeatForever(autoreverses: true)) {
            crownPositions[index].y += CGFloat.random(in: -100...100)
            crownPositions[index].rotation += Double.random(in: -45...45)
        }
    }
}

struct CrownPosition {
    let id: UUID
    var x: CGFloat
    var y: CGFloat
    let size: CGFloat
    let opacity: Double
    var rotation: Double
}

// MARK: - Enhanced Confetti View
struct ConfettiView: View {
    @State private var confettiPieces: [ConfettiPiece] = []
    
    var body: some View {
        ZStack {
            ForEach(confettiPieces, id: \.id) { piece in
                RoundedRectangle(cornerRadius: 2)
                    .fill(piece.color)
                    .frame(width: 10, height: 10)
                    .position(x: piece.x, y: piece.y)
                    .rotationEffect(.degrees(piece.rotation))
                    .opacity(piece.opacity)
                    .shadow(color: piece.color.opacity(0.3), radius: 4, x: 2, y: 2)
            }
        }
        .onAppear {
            createConfetti()
            animateConfetti()
        }
    }
    
    private func createConfetti() {
        let colors: [Color] = [.red, .blue, .green, .yellow, .orange, .purple, .pink, .cyan, .mint]
        
        for _ in 0..<80 {
            let piece = ConfettiPiece(
                id: UUID(),
                x: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                y: -50,
                color: colors.randomElement() ?? .blue,
                rotation: Double.random(in: 0...360),
                opacity: 1.0
            )
            confettiPieces.append(piece)
        }
    }
    
    private func animateConfetti() {
        withAnimation(.easeOut(duration: 3.0)) {
            for i in 0..<confettiPieces.count {
                confettiPieces[i].y = UIScreen.main.bounds.height + 100
                confettiPieces[i].x += CGFloat.random(in: -150...150)
                confettiPieces[i].rotation += Double.random(in: 360...720)
                confettiPieces[i].opacity = 0.0
            }
        }
    }
}

struct ConfettiPiece {
    let id: UUID
    var x: CGFloat
    var y: CGFloat
    let color: Color
    var rotation: Double
    var opacity: Double
}

#Preview {
    LoginView()
}
