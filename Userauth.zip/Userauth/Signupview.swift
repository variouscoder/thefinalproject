import SwiftUI
import Firebase
import FirebaseAuth

struct SignupView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var isConfirmPasswordVisible: Bool = false
    @State private var isLoading: Bool = false
    @State private var errorMessage: String = ""
    @State private var successMessage: String = ""
    @State private var showConfetti = false
    @Environment(\.dismiss) private var dismiss
    
    // Hover states
    @State private var isSignUpButtonHovered = false
    @State private var isLoginLinkHovered = false
    @State private var isPasswordToggleHovered = false
    @State private var isConfirmPasswordToggleHovered = false
    
    // Animation states
    @State private var titleOffset: CGFloat = -50
    @State private var titleOpacity: Double = 0
    @State private var formOffset: CGFloat = 30
    @State private var formOpacity: Double = 0
    
    var body: some View {
        ZStack {
            // Modern gradient background matching LoginView
            LinearGradient(
                colors: [
                    Color(red: 0.1, green: 0.1, blue: 0.2),
                    Color(red: 0.2, green: 0.2, blue: 0.3),
                    Color(red: 0.15, green: 0.15, blue: 0.25)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            // Enhanced animated background
            AnimatedStarsView()
            
            // Background Image
            VStack {
                Spacer()
                Image("vro")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(height: 350)
                    .clipped()
                    .opacity(0.25)
            }
            .ignoresSafeArea(edges: .bottom)
            
            // Confetti Effect
            if showConfetti {
                EnhancedConfettiView()
            }
            
            ScrollView {
                VStack(spacing: 32) {
                    // Enhanced title section with animations
                    VStack(spacing: 16) {
                        Text("Create Account")
                            .font(.system(size: 44, weight: .bold, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [
                                        Color.cyan.opacity(0.9),
                                        Color.blue.opacity(0.8),
                                        Color.purple.opacity(0.7)
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .shadow(color: .cyan.opacity(0.3), radius: 10, x: 0, y: 5)
                            .offset(y: titleOffset)
                            .opacity(titleOpacity)
                        
                        Text("Join our community today")
                            .font(.system(size: 17, weight: .medium))
                            .foregroundColor(.white.opacity(0.8))
                            .offset(y: titleOffset)
                            .opacity(titleOpacity)
                    }
                    .padding(.top, 50)
                    
                    // Enhanced form container
                    VStack(spacing: 28) {
                        // Email Input with enhanced styling
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("Email Address")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.9))
                                
                                Spacer()
                                
                                if !email.isEmpty {
                                    Image(systemName: isValidEmail(email) ? "checkmark.circle.fill" : "xmark.circle.fill")
                                        .foregroundColor(isValidEmail(email) ? .green : .red)
                                        .font(.system(size: 16))
                                }
                            }
                            .padding(.leading, 4)
                            
                            ZStack {
                                RoundedRectangle(cornerRadius: 18)
                                    .fill(.ultraThinMaterial)
                                    .frame(height: 60)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 18)
                                            .stroke(
                                                LinearGradient(
                                                    colors: email.isEmpty ?
                                                        [.white.opacity(0.2), .white.opacity(0.1)] :
                                                        (isValidEmail(email) ?
                                                            [.green.opacity(0.6), .green.opacity(0.3)] :
                                                            [.red.opacity(0.6), .red.opacity(0.3)]
                                                        ),
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                ),
                                                lineWidth: 2
                                            )
                                    )
                                    .shadow(color: .cyan.opacity(0.1), radius: 8, x: 0, y: 4)
                                
                                HStack(spacing: 12) {
                                    ZStack {
                                        Circle()
                                            .fill(.ultraThinMaterial)
                                            .frame(width: 36, height: 36)
                                        
                                        Image(systemName: "envelope")
                                            .foregroundColor(.cyan.opacity(0.8))
                                            .font(.system(size: 16, weight: .semibold))
                                    }
                                    
                                    TextField("Enter your email", text: $email)
                                        .font(.system(size: 17, weight: .medium))
                                        .foregroundColor(.white)
                                        .autocapitalization(.none)
                                        .keyboardType(.emailAddress)
                                }
                                .padding(.horizontal, 18)
                            }
                        }
                        
                        // Password Input with enhanced styling
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("Password")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.9))
                                
                                Spacer()
                                
                                if !password.isEmpty {
                                    Image(systemName: password.count >= 6 ? "checkmark.circle.fill" : "xmark.circle.fill")
                                        .foregroundColor(password.count >= 6 ? .green : .red)
                                        .font(.system(size: 16))
                                }
                            }
                            .padding(.leading, 4)
                            
                            ZStack {
                                RoundedRectangle(cornerRadius: 18)
                                    .fill(.ultraThinMaterial)
                                    .frame(height: 60)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 18)
                                            .stroke(
                                                LinearGradient(
                                                    colors: password.isEmpty ?
                                                        [.white.opacity(0.2), .white.opacity(0.1)] :
                                                        (password.count >= 6 ?
                                                            [.green.opacity(0.6), .green.opacity(0.3)] :
                                                            [.orange.opacity(0.6), .orange.opacity(0.3)]
                                                        ),
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                ),
                                                lineWidth: 2
                                            )
                                    )
                                    .shadow(color: .purple.opacity(0.1), radius: 8, x: 0, y: 4)
                                
                                HStack(spacing: 12) {
                                    ZStack {
                                        Circle()
                                            .fill(.ultraThinMaterial)
                                            .frame(width: 36, height: 36)
                                        
                                        Image(systemName: "lock")
                                            .foregroundColor(.purple.opacity(0.8))
                                            .font(.system(size: 16, weight: .semibold))
                                    }
                                    
                                    if isPasswordVisible {
                                        TextField("Enter your password", text: $password)
                                    } else {
                                        SecureField("Enter your password", text: $password)
                                    }
                                    
                                    Button(action: {
                                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                            isPasswordVisible.toggle()
                                        }
                                    }) {
                                        ZStack {
                                            Circle()
                                                .fill(.ultraThinMaterial)
                                                .frame(width: 32, height: 32)
                                                .scaleEffect(isPasswordToggleHovered ? 1.1 : 1.0)
                                            
                                            Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                                                .foregroundColor(.white.opacity(0.7))
                                                .font(.system(size: 14, weight: .semibold))
                                        }
                                    }
                                    .onHover { hovering in
                                        withAnimation(.easeInOut(duration: 0.2)) {
                                            isPasswordToggleHovered = hovering
                                        }
                                    }
                                }
                                .font(.system(size: 17, weight: .medium))
                                .foregroundColor(.white)
                                .padding(.horizontal, 18)
                            }
                        }
                        
                        // Confirm Password Input with enhanced styling
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("Confirm Password")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.9))
                                
                                Spacer()
                                
                                if !confirmPassword.isEmpty {
                                    Image(systemName: passwordsMatch() ? "checkmark.circle.fill" : "xmark.circle.fill")
                                        .foregroundColor(passwordsMatch() ? .green : .red)
                                        .font(.system(size: 16))
                                }
                            }
                            .padding(.leading, 4)
                            
                            ZStack {
                                RoundedRectangle(cornerRadius: 18)
                                    .fill(.ultraThinMaterial)
                                    .frame(height: 60)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 18)
                                            .stroke(
                                                LinearGradient(
                                                    colors: confirmPassword.isEmpty ?
                                                        [.white.opacity(0.2), .white.opacity(0.1)] :
                                                        (passwordsMatch() ?
                                                            [.green.opacity(0.6), .green.opacity(0.3)] :
                                                            [.red.opacity(0.6), .red.opacity(0.3)]
                                                        ),
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                ),
                                                lineWidth: 2
                                            )
                                    )
                                    .shadow(color: .pink.opacity(0.1), radius: 8, x: 0, y: 4)
                                
                                HStack(spacing: 12) {
                                    ZStack {
                                        Circle()
                                            .fill(.ultraThinMaterial)
                                            .frame(width: 36, height: 36)
                                        
                                        Image(systemName: "lock.shield")
                                            .foregroundColor(.pink.opacity(0.8))
                                            .font(.system(size: 16, weight: .semibold))
                                    }
                                    
                                    if isConfirmPasswordVisible {
                                        TextField("Confirm your password", text: $confirmPassword)
                                    } else {
                                        SecureField("Confirm your password", text: $confirmPassword)
                                    }
                                    
                                    Button(action: {
                                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                            isConfirmPasswordVisible.toggle()
                                        }
                                    }) {
                                        ZStack {
                                            Circle()
                                                .fill(.ultraThinMaterial)
                                                .frame(width: 32, height: 32)
                                                .scaleEffect(isConfirmPasswordToggleHovered ? 1.1 : 1.0)
                                            
                                            Image(systemName: isConfirmPasswordVisible ? "eye.slash.fill" : "eye.fill")
                                                .foregroundColor(.white.opacity(0.7))
                                                .font(.system(size: 14, weight: .semibold))
                                        }
                                    }
                                    .onHover { hovering in
                                        withAnimation(.easeInOut(duration: 0.2)) {
                                            isConfirmPasswordToggleHovered = hovering
                                        }
                                    }
                                }
                                .font(.system(size: 17, weight: .medium))
                                .foregroundColor(.white)
                                .padding(.horizontal, 18)
                            }
                        }
                        
                        // Enhanced Password Requirements
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Password Requirements")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(.white.opacity(0.9))
                            
                            HStack(spacing: 8) {
                                Image(systemName: password.count >= 6 ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(password.count >= 6 ? .green : .white.opacity(0.5))
                                    .font(.system(size: 14))
                                
                                Text("At least 6 characters")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(password.count >= 6 ? .green : .white.opacity(0.7))
                            }
                            
                            HStack(spacing: 8) {
                                Image(systemName: passwordsMatch() && !confirmPassword.isEmpty ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(passwordsMatch() && !confirmPassword.isEmpty ? .green : .white.opacity(0.5))
                                    .font(.system(size: 14))
                                
                                Text("Passwords must match")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(passwordsMatch() && !confirmPassword.isEmpty ? .green : .white.opacity(0.7))
                            }
                        }
                        .padding(.horizontal, 4)
                        .padding(.top, 8)
                    }
                    .padding(.horizontal, 24)
                    .offset(y: formOffset)
                    .opacity(formOpacity)
                    
                    // Error/Success Messages with enhanced styling
                    if !errorMessage.isEmpty {
                        HStack(spacing: 12) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundColor(.red)
                                .font(.system(size: 16))
                            
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .font(.system(size: 15, weight: .medium))
                                .multilineTextAlignment(.leading)
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 16)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(.ultraThinMaterial)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(.red.opacity(0.5), lineWidth: 1)
                                )
                        )
                        .padding(.horizontal, 24)
                        .shadow(color: .red.opacity(0.2), radius: 8, x: 0, y: 4)
                    }
                    
                    if !successMessage.isEmpty {
                        HStack(spacing: 12) {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                                .font(.system(size: 16))
                            
                            Text(successMessage)
                                .foregroundColor(.green)
                                .font(.system(size: 15, weight: .medium))
                                .multilineTextAlignment(.leading)
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 16)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(.ultraThinMaterial)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(.green.opacity(0.5), lineWidth: 1)
                                )
                        )
                        .padding(.horizontal, 24)
                        .shadow(color: .green.opacity(0.2), radius: 8, x: 0, y: 4)
                    }
                    
                    // Enhanced Sign Up Button
                    Button(action: {
                        signUp()
                    }) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 18)
                                .fill(
                                    LinearGradient(
                                        colors: [
                                            Color.cyan,
                                            Color.blue,
                                            Color.purple
                                        ],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(height: 60)
                                .shadow(
                                    color: .cyan.opacity(isSignUpButtonHovered ? 0.6 : 0.3),
                                    radius: isSignUpButtonHovered ? 25 : 12,
                                    x: 0,
                                    y: isSignUpButtonHovered ? 10 : 5
                                )
                                .scaleEffect(isSignUpButtonHovered ? 1.02 : 1.0)
                            
                            if isLoading {
                                HStack(spacing: 12) {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                        .scaleEffect(1.3)
                                    
                                    Text("Creating Account...")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundColor(.white)
                                }
                            } else {
                                HStack(spacing: 16) {
                                    Image(systemName: "person.badge.plus.fill")
                                        .font(.system(size: 20, weight: .bold))
                                    
                                    Text("Create Account")
                                        .font(.system(size: 18, weight: .bold))
                                }
                                .foregroundColor(.white)
                            }
                        }
                    }
                    .disabled(isLoading || !isFormValid())
                    .opacity((isLoading || !isFormValid()) ? 0.6 : 1.0)
                    .padding(.horizontal, 24)
                    .padding(.top, 16)
                    .onHover { hovering in
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                            isSignUpButtonHovered = hovering
                        }
                    }
                    
                    // Enhanced Login Link
                    VStack(spacing: 16) {
                        // Divider
                        HStack {
                            Rectangle()
                                .fill(.white.opacity(0.3))
                                .frame(height: 1)
                            
                            Text("Already have an account?")
                                .font(.system(size: 15, weight: .medium))
                                .foregroundColor(.white.opacity(0.7))
                                .padding(.horizontal, 20)
                            
                            Rectangle()
                                .fill(.white.opacity(0.3))
                                .frame(height: 1)
                        }
                        .padding(.horizontal, 24)
                        
                        Button(action: {
                            dismiss()
                        }) {
                            HStack(spacing: 12) {
                                Image(systemName: "arrow.left.circle.fill")
                                    .font(.system(size: 18))
                                
                                Text("Sign In Instead")
                                    .font(.system(size: 17, weight: .semibold))
                            }
                            .foregroundColor(.white)
                            .padding(.vertical, 16)
                            .padding(.horizontal, 32)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .stroke(
                                        LinearGradient(
                                            colors: [.white.opacity(0.4), .white.opacity(0.2)],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        ),
                                        lineWidth: 2
                                    )
                                    .background(
                                        RoundedRectangle(cornerRadius: 16)
                                            .fill(.ultraThinMaterial.opacity(isLoginLinkHovered ? 0.4 : 0.2))
                                    )
                            )
                            .scaleEffect(isLoginLinkHovered ? 1.02 : 1.0)
                            .shadow(
                                color: .white.opacity(isLoginLinkHovered ? 0.3 : 0.1),
                                radius: isLoginLinkHovered ? 18 : 8,
                                x: 0,
                                y: isLoginLinkHovered ? 8 : 3
                            )
                        }
                        .onHover { hovering in
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                isLoginLinkHovered = hovering
                            }
                        }
                    }
                    .padding(.top, 20)
                    
                    Spacer(minLength: 60)
                }
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            withAnimation(.easeOut(duration: 0.8).delay(0.2)) {
                titleOffset = 0
                titleOpacity = 1
            }
            
            withAnimation(.easeOut(duration: 0.8).delay(0.5)) {
                formOffset = 0
                formOpacity = 1
            }
        }
    }
    
    // MARK: - Authentication Functions
    private func signUp() {
        guard isFormValid() else {
            errorMessage = "Please fill in all fields correctly"
            return
        }
        
        isLoading = true
        errorMessage = ""
        successMessage = ""
        
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            DispatchQueue.main.async {
                isLoading = false
                
                if let error = error {
                    errorMessage = getErrorMessage(from: error)
                } else {
                    successMessage = "Account created successfully! 🎉"
                    showConfetti = true
                    
                    // Send email verification
                    sendEmailVerification()
                    
                    // Navigate back to login page after successful signup
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func sendEmailVerification() {
        Auth.auth().currentUser?.sendEmailVerification { error in
            if let error = error {
                print("Error sending verification email: \(error.localizedDescription)")
            } else {
                print("Verification email sent")
            }
        }
    }
    
    // MARK: - Validation Functions
    private func isFormValid() -> Bool {
        return !email.isEmpty &&
               !password.isEmpty &&
               !confirmPassword.isEmpty &&
               password.count >= 6 &&
               passwordsMatch() &&
               isValidEmail(email)
    }
    
    private func passwordsMatch() -> Bool {
        return !password.isEmpty && !confirmPassword.isEmpty && password == confirmPassword
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    private func getErrorMessage(from error: Error) -> String {
        if let authError = error as NSError?, let errorCode = AuthErrorCode(rawValue: authError.code) {
            switch errorCode {
            case .invalidEmail:
                return "Invalid email address"
            case .emailAlreadyInUse:
                return "An account with this email already exists"
            case .weakPassword:
                return "Password is too weak. Please choose a stronger password"
            case .networkError:
                return "Network error. Please check your connection"
            case .tooManyRequests:
                return "Too many requests. Please try again later"
            default:
                return "Account creation failed. Please try again"
            }
        }
        return error.localizedDescription
    }
}

// MARK: - Animated Stars Background View
struct AnimatedStarsView: View {
    @State private var starPositions: [StarPosition] = []
    
    var body: some View {
        ZStack {
            ForEach(starPositions, id: \.id) { star in
                Image(systemName: star.symbol)
                    .font(.system(size: star.size))
                    .foregroundStyle(
                        LinearGradient(
                            colors: star.colors,
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .position(x: star.x, y: star.y)
                    .rotationEffect(.degrees(star.rotation))
                    .opacity(star.opacity)
                    .shadow(color: star.colors.first?.opacity(0.4) ?? .clear, radius: 6, x: 2, y: 2)
            }
        }
        .onAppear {
            createStars()
            animateStars()
        }
    }
    
    private func createStars() {
        let symbols = ["star.fill", "sparkles", "star.circle.fill", "diamond.fill"]
        let colorSets: [[Color]] = [
            [.cyan, .blue],
            [.purple, .pink],
            [.yellow, .orange],
            [.mint, .teal],
            [.indigo, .purple]
        ]
        
        for _ in 0..<12 {
            let star = StarPosition(
                id: UUID(),
                x: CGFloat.random(in: 50...UIScreen.main.bounds.width - 50),
                y: CGFloat.random(in: 100...UIScreen.main.bounds.height - 100),
                size: CGFloat.random(in: 20...35),
                opacity: Double.random(in: 0.3...0.7),
                rotation: Double.random(in: 0...360),
                symbol: symbols.randomElement() ?? "star.fill",
                colors: colorSets.randomElement() ?? [.cyan, .blue]
            )
            starPositions.append(star)
        }
    }
    
    private func animateStars() {
        for i in 0..<starPositions.count {
            let duration = Double.random(in: 4.0...8.0)
            let delay = Double.random(in: 0...3.0)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                animateStar(at: i, duration: duration)
            }
        }
    }
    
    private func animateStar(at index: Int, duration: Double) {
        withAnimation(.easeInOut(duration: duration).repeatForever(autoreverses: true)) {
            starPositions[index].y += CGFloat.random(in: -80...80)
            starPositions[index].x += CGFloat.random(in: -50...50)
            starPositions[index].rotation += Double.random(in: -90...90)
            starPositions[index].opacity = Double.random(in: 0.2...0.8)
        }
    }
}

struct StarPosition {
    let id: UUID
    var x: CGFloat
    var y: CGFloat
    let size: CGFloat
    var opacity: Double
    var rotation: Double
    let symbol: String
    let colors: [Color]
}

// MARK: - Enhanced Confetti View
struct EnhancedConfettiView: View {
    @State private var confettiPieces: [EnhancedConfettiPiece] = []
    
    var body: some View {
        ZStack {
            ForEach(confettiPieces, id: \.id) { piece in
                Image(systemName: piece.symbol)
                    .font(.system(size: piece.size, weight: .bold))
                    .foregroundColor(piece.color)
                    .position(x: piece.x, y: piece.y)
                    .rotationEffect(.degrees(piece.rotation))
                    .opacity(piece.opacity)
                    .shadow(color: piece.color.opacity(0.5), radius: 4, x: 2, y: 2)
            }
        }
        .onAppear {
            createEnhancedConfetti()
            animateEnhancedConfetti()
        }
    }
    
    private func createEnhancedConfetti() {
        let colors: [Color] = [.red, .blue, .green, .yellow, .orange, .purple, .pink, .cyan, .mint, .teal]
        let symbols = ["star.fill", "heart.fill", "diamond.fill", "circle.fill", "triangle.fill", "sparkles"]
        
        for _ in 0..<100 {
            let piece = EnhancedConfettiPiece(
                id: UUID(),
                x: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                y: -100,
                color: colors.randomElement() ?? .blue,
                rotation: Double.random(in: 0...360),
                opacity: 1.0,
                symbol: symbols.randomElement() ?? "star.fill",
                size: CGFloat.random(in: 12...24)
            )
            confettiPieces.append(piece)
        }
    }
    
    private func animateEnhancedConfetti() {
        withAnimation(.easeOut(duration: 4.0)) {
            for i in 0..<confettiPieces.count {
                confettiPieces[i].y = UIScreen.main.bounds.height + 150
                confettiPieces[i].x += CGFloat.random(in: -200...200)
                confettiPieces[i].rotation += Double.random(in: 720...1440)
                confettiPieces[i].opacity = 0.0
            }
        }
    }
}

struct EnhancedConfettiPiece {
    let id: UUID
    var x: CGFloat
    var y: CGFloat
    let color: Color
    var rotation: Double
    var opacity: Double
    let symbol: String
    let size: CGFloat
}

#Preview {
    SignupView()
}
