//
//  UserauthTests.swift
//  UserauthTests
//
//  Created by Tarik Eddins on 6/30/25.
//

import Testing
@testable import Userauth

struct UserauthTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
